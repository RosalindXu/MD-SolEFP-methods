#/bin/csh -f 

#cd source 
# make clean
# make 

#cd ../spline
 #make clean
 #make lib
#cd ..


ifort -O3 -o ../oPM3_combined oPM3.f atomType.f cap.f center.f getEnergy.f getEnergy-dft.f getEnergy-mp2.f getEnergy-gen.f lsfit.f monitor.f morse.f mrqmin.f oqmmm_freq.f proteincap.f readProteinXYZ.f readSmallXYZ.f rotate_config.f scale.f selectSolvent.f setProteinXYZ.f setSmallXYZ.f lib/libmopac.a lib/spline.a libxtc.a -ldl -lstdc++   

